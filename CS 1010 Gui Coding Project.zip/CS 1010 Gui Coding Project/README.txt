Group 1
Mathew Benitez, Nicholas Miller, Gustavo Trejo

The program should work like a normal pyhton file, the only thing needed is turtle for imaging. 
It should work fine but if it's not running just install turtle with 'pip install turtle' into python

The goal is to get the highest score you can by getting the most correct and win by answering all of the flags correctly. 
There is a help button which skips the flag if you need to skip it, there are only 3 helps per time a round is played.
Then there are lives and you have 3, run out then game over. You lose lives by getting a guess wrong.
Points are calculated on how many flags are guessed correctly in the round, 1 point per flag.
There are 2 difficulties with normal being 10 and hard adding 9 additional flags to the pool.

To guess just type in the name of the country that the flag is from in all lower case.


Flag creation credit goes to Geek Tutorials : https://www.youtube.com/channel/UCzPI8bZBZZIL5eftCCxEN1g 


Flags used below














Flags used (france, belgium, japan, ireland, romania, italy, sweden, finland, iceland, norway,
          netherlands,monaco, poland, germany, austria, estonia, bulgaria, hungary, lithuania)